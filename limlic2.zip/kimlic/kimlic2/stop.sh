#!/bin/bash
killall -s SIGKILL geth bootnode constellation-node
